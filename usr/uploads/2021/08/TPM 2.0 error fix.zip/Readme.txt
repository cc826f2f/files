替换 sources 文件夹里的 appraiserres.dll 文件

原文链接：https://www.schan.top/archives/69/